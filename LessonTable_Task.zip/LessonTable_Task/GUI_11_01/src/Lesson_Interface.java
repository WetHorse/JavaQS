public interface Lesson_Interface{

    String getSubject();
    void setSubject(String subjectToAdd);

    String getDay();
    void setDay(String dayToAdd);

    String getBlock();
    void setBlock(String blockToSet);


}
