import java.util.List;

public class Lesson implements Lesson_Interface{
    private String subject;
    private String day;
    private String block;



    public Lesson(String subject, String day, String block){
        this.day = day;
        this.block = block;
        this.subject = subject;

    }

    @Override
    public String getSubject() {
        return subject;
    }

    @Override
    public void setSubject(String subjectToAdd) {
        this.subject = subjectToAdd;
    }

    @Override
    public String getDay() {
        return day;
    }

    @Override
    public void setDay(String dayToAdd) {
        this.day = dayToAdd;
    }

    @Override
    public String getBlock() {
        return block;
    }

    @Override
    public void setBlock(String blockToSet) {
        this.block = blockToSet;
    }


}
