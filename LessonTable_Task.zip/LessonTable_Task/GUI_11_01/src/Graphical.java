import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Graphical extends JFrame implements  ActionListener {
    private final JTable timetable;
    private final DefaultTableModel tableModel;
    private final List<Lesson> lessons;



    JPanel buttonPanel = new JPanel();

    JPanel addPanel = new JPanel(new GridLayout(0, 1));

    JPanel editPanel = new JPanel(new GridLayout(0, 1));

    JButton addButton = new JButton("Add");
    JButton deleteButton = new JButton("Delete");
    JButton editButton = new JButton("Edit");
    public Graphical() {
        setTitle("School Schedule");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setSize(800, 800);
        setBackground(Color.DARK_GRAY);

        lessons = new ArrayList<>();
        tableModel = new DefaultTableModel();
        timetable = new JTable(tableModel);

        tableModel.addColumn("Subject");
        tableModel.addColumn("Day");
        tableModel.addColumn("Block");

        JScrollPane scrollPane = new JScrollPane(timetable);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        addButton.addActionListener(this);
        deleteButton.addActionListener(this);
        editButton.addActionListener(this);

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(editButton);
        getContentPane().add(buttonPanel, BorderLayout.NORTH);


        setVisible(true);
    }


        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource() == addButton){
                JTextField subjectAddField = new JTextField();
                JTextField dateAddField = new JTextField();
                JTextField groupAddField = new JTextField();


                addPanel.add(new JLabel("Subject"));
                addPanel.add(subjectAddField);
                addPanel.add(new JLabel("Date"));
                addPanel.add(dateAddField);
                addPanel.add(new JLabel("Group"));
                addPanel.add(groupAddField);


                int confirmDialog = JOptionPane.showConfirmDialog(null, addPanel, "Add new lesson:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (confirmDialog == JOptionPane.OK_OPTION){
                    String subject = subjectAddField.getText();
                    String date = dateAddField.getText();
                    String group = groupAddField.getText();

                    Lesson lesson = new Lesson(subject,date,group);
                    lessons.add(lesson);
                    addToTable(lesson);



                }else {
                    JOptionPane.showMessageDialog(null, "Error! Invalid format!", "Error! Something went wrong...", JOptionPane.ERROR_MESSAGE);

                }
            }else if(e.getSource() == deleteButton){
                int [] rows = timetable.getSelectedRows();
                if(rows.length > 0){
                    int choose = JOptionPane.showConfirmDialog(null, "Are you sure? ","Confirm the deleteting", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                    if(choose == JOptionPane.YES_OPTION){
                        for(int i = rows.length -1; i>=0; i-- ){
                            int selectedRow = rows[i];
                            lessons.remove(selectedRow);
                            tableModel.removeRow(selectedRow);
                        }
                    }else {
                        JOptionPane.showMessageDialog(null, "Please select lessons to delete", "Error! Something went wrong! ", JOptionPane.ERROR_MESSAGE);

                    }
                }

            }else if(e.getSource() == editButton){
                int selectedRow = timetable.getSelectedRow();
                if(selectedRow != -1){
                    Lesson lesson = lessons.get(selectedRow);

                    JTextField subject = new JTextField(lesson.getSubject());
                    JTextField date = new JTextField(lesson.getDay());
                    JTextField group = new JTextField(lesson.getBlock());


                    editPanel.add(new JLabel("Subject"));
                    editPanel.add(subject);
                    editPanel.add(new JLabel("Date"));
                    editPanel.add(date);
                    editPanel.add(new JLabel("Group"));
                    editPanel.add(group);


                    int choose = JOptionPane.showConfirmDialog(null, editPanel, "Edit lesson?", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if(choose == JOptionPane.OK_OPTION){
                        String subjectNew = subject.getText();
                        String dateNew = date.getText();
                        String groupNew = group.getText();

                        lesson.setSubject(subjectNew);
                        lesson.setDay(dateNew);
                        lesson.setBlock(groupNew);

                        updateTable();
                    }else{
                        JOptionPane.showMessageDialog(null,"Error! Something went wrong!", "Error!", JOptionPane.ERROR_MESSAGE);
                    }

                }
            }

        }

        public void addToTable(Lesson lesson){
            tableModel.addRow(new Object[]{lesson.getSubject(), lesson.getDay(), lesson.getBlock()});

        }

        private void updateTable(){
            tableModel.setRowCount(0);
            for(Lesson lesson : lessons){
                addToTable(lesson);
            }
        }

//
//    private boolean correctLessonData(String subject, String day, String block) {
//
//    }

}
