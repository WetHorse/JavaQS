import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        Graphical graphical = new Graphical();
        graphical.setVisible(true);

    }
}
