import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class s26850_Project4 extends JFrame {
    private static final int ROWS = 16;
    private static final int COLS = 25;

    private int CELL_SIZE = 35;

    private JTable table;
    private DefaultTableModel model;

    private ScorePanel scorePanel;

    public s26850_Project4() {
        setTitle("Snake Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(875, 695));
        setResizable(false);


        scorePanel = new ScorePanel();

        model = new DefaultTableModel(ROWS, COLS);
        table = new JTable(model);
        table.setRowHeight(CELL_SIZE);
        table.setTableHeader(null);
        table.setEnabled(false);
        table.setBackground(new Color(0, 255, 127));
        table.setDefaultRenderer(Object.class, new ImageIconCellRenderer());
        this.setLayout(new BorderLayout());
        add(table, BorderLayout.SOUTH);
        add(scorePanel, BorderLayout.NORTH);

        pack();
        setLocationRelativeTo(null);

        setVisible(true);
    }

    private class ImageIconCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {
            JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            if (value instanceof ImageIcon) {
                label.setIcon((ImageIcon) value);
            } else {
                label.setIcon(null);
            }
            return label;
        }
    }

    public ScorePanel getScorePanel() {
        return scorePanel;
    }


    public static void main(String[] args) {
        String nickName = JOptionPane.showInputDialog("Input your nickname: ");
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                s26850_Project4 gui = new s26850_Project4();
                Gameplay gameLogic = new Gameplay();
                gameLogic.setTable(gui.table);
                gameLogic.setModel(gui.model);
                gameLogic.setGui(gui);

                gui.scorePanel.setNickName(nickName);

                gameLogic.addSnakeGameEventListener(new SnakeEventListener() {
                    @Override
                    public void onSnakeGameEvent(SnakeEvent event) {
                        switch (event.getEventTypes()) {
                            case TICK:

                                break;
                            case APPLE_EATED:
                                gui.getScorePanel().setApplesEaten(gameLogic.getApplesEaten());
                                System.out.println(gameLogic.getApplesEaten());
                                break;
                            case BORDER_COLLISION:
                                openNewFrame();
                                break;
                            case SNAKE_TO_SNAKE_COLLISION:
                                new ReadWrite();
                                ReadWrite.writePlayerInfo("file.bin",nickName, gameLogic.getApplesEaten());
                                openNewFrame();
                                break;
                        }
                    }
                });
                gameLogic.startGame();
            }
        });
    }

    private static void openNewFrame() {
        JFrame frame = new JFrame("New Frame");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 600);
        frame.setLocationRelativeTo(null);

        String newNick = null;
        int newScore =0;

        new ReadWrite();
        String[] playerInfo = ReadWrite.readPlayerInfo("file.bin");

        if(playerInfo !=null ){
            newNick = playerInfo[0];
            newScore = Integer.parseInt(playerInfo[1]);
        }

        JLabel label = new JLabel(newNick);
        JLabel label1 = new JLabel(String.valueOf(newScore));
        label.setHorizontalAlignment(SwingConstants.CENTER);

        frame.setLayout(new BorderLayout());
        frame.getContentPane().add(label, BorderLayout.WEST);
        frame.getContentPane().add(label1, BorderLayout.EAST);
        frame.setVisible(true);
    }

    public static class ReadWrite {
        public static void writePlayerInfo(String filename, String nickname, int score) {
            try (FileOutputStream fos = new FileOutputStream(filename)) {
                byte[] nicknameBytes = nickname.getBytes();
                int nicknameLength = nicknameBytes.length;

                fos.write((byte) nicknameLength);

                fos.write(nicknameBytes);

                fos.write((score >> 24) & 0xFF);
                fos.write((score >> 16) & 0xFF);
                fos.write((score >> 8) & 0xFF);
                fos.write(score & 0xFF);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public static String[] readPlayerInfo(String filename) {
            try (FileInputStream fis = new FileInputStream(filename)) {
                int nicknameLength = fis.read();

                byte[] nicknameBytes = new byte[nicknameLength];
                fis.read(nicknameBytes);
                String nickname = new String(nicknameBytes);


                int score = (fis.read() << 24) | (fis.read() << 16) | (fis.read() << 8) | fis.read();

                return new String[]{nickname, Integer.toString(score)};
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    }

interface SnakeEventListener {
    void onSnakeGameEvent(SnakeEvent snakeEvent);
}
class SnakeEvent {
    public enum EventTypes{
        TICK,BORDER_COLLISION,SNAKE_TO_SNAKE_COLLISION,APPLE_EATED
    }
    private EventTypes eventTypes;

    public SnakeEvent(EventTypes eventTypes){
        this.eventTypes = eventTypes;
    }

    public EventTypes getEventTypes(){
        return eventTypes;
    }
}
class Gameplay {
    private  final int ROWS = 16;
    private final int COLS = 25;
    private  final int GAME_SPEED = 200;

    private  final int EMPTY = 0;
    private  final int SNAKE = 1;
    private  final int APPLE = 2;

    private final int UP = 0;
    private final int RIGHT = 1;
    private  final int DOWN = 2;
    private  final int LEFT = 3;

    private int[][] field;
    private java.util.List<Coordinate> snake;
    private Coordinate apple;
    private int direction;
    private boolean isGameRunning;

    private int applesEated =0;

    private JTable table;
    private DefaultTableModel model;
    private Thread gameThread;
    private List<SnakeEventListener> eventListeners;

    public Gameplay() {
        eventListeners = new ArrayList<>();
    }

    public void addSnakeGameEventListener(SnakeEventListener listener) {
        eventListeners.add(listener);
    }

    public void setTable(JTable table) {
        this.table = table;
    }

    public void setModel(DefaultTableModel model) {
        this.model = model;
    }

    public void setGui(s26850_Project4 gui) {

        gui.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
        });

        gui.setFocusable(true);
    }

    public void startGame() {
        field = new int[ROWS][COLS];
        snake = new ArrayList<>();
        direction = RIGHT;
        isGameRunning = true;

        initializeSnake();
        generateApple();

        gameThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (isGameRunning) {
                    updateSnake();
                    checkCollision();
                    updateDisplay();
                    fireSnakeGameEvent(new SnakeEvent(SnakeEvent.EventTypes.TICK));

                    try {
                        Thread.sleep(GAME_SPEED);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        gameThread.start();
    }

    private void initializeSnake() {
        int startX = COLS / 2;
        int startY = ROWS / 2;

        snake.add(new Coordinate(startX, startY));
        snake.add(new Coordinate(startX - 1, startY));
        snake.add(new Coordinate(startX - 2, startY));

        for (Coordinate coordinate : snake) {
            field[coordinate.getY()][coordinate.getX()] = SNAKE;
        }
    }

    private void generateApple() {
        Random random = new Random();
        int x = random.nextInt(COLS);
        int y = random.nextInt(ROWS);

        while (field[y][x] != EMPTY) {
            x = random.nextInt(COLS);
            y = random.nextInt(ROWS);
        }

        apple = new Coordinate(x, y);
        field[y][x] = APPLE;
    }

    private void updateSnake() {
        Coordinate head = snake.get(0);
        Coordinate newHead;

        switch (direction) {
            case UP:
                newHead = new Coordinate(head.getX(), head.getY() - 1);
                break;
            case RIGHT:
                newHead = new Coordinate(head.getX() + 1, head.getY());
                break;
            case DOWN:
                newHead = new Coordinate(head.getX(), head.getY() + 1);
                break;
            case LEFT:
                newHead = new Coordinate(head.getX() - 1, head.getY());
                break;
            default:
                return;
        }

        snake.add(0, newHead);

        if (newHead.equals(apple)) {
            field[apple.getY()][apple.getX()] = EMPTY;
            generateApple();
            applesEated++;
            setApplesEated(applesEated);
            fireSnakeGameEvent(new SnakeEvent(SnakeEvent.EventTypes.APPLE_EATED));
        } else {
            Coordinate tail = snake.remove(snake.size() - 1);
            field[tail.getY()][tail.getX()] = EMPTY;
        }

        field[newHead.getY()][newHead.getX()] = SNAKE;
    }

    private void checkCollision() {
        Coordinate head = snake.get(0);

        if (head.getX() < 0 || head.getX() >= COLS || head.getY() < 0 || head.getY() >= ROWS) {
            fireSnakeGameEvent(new SnakeEvent(SnakeEvent.EventTypes.BORDER_COLLISION));
            isGameRunning = false;

        }

        for (int i = 1; i < snake.size(); i++) {
            if (head.equals(snake.get(i))) {
                isGameRunning = false;
                fireSnakeGameEvent(new SnakeEvent(SnakeEvent.EventTypes.SNAKE_TO_SNAKE_COLLISION));
                break;
            }
        }
    }

    private void updateDisplay() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                for (int row = 0; row < ROWS; row++) {
                    for (int col = 0; col < COLS; col++) {
                        switch (field[row][col]) {
                            case EMPTY:
                                model.setValueAt(null, row, col);
                                break;
                            case SNAKE:
                                model.setValueAt("O", row, col);
                                break;
                            case APPLE:
                                model.setValueAt("U+1F34E" , row, col);
                                break;
                        }
                    }
                }
            }
        });
    }



    public int getApplesEaten() {
        return applesEated;
    }

    public void setApplesEated(int applesEated1){
        this.applesEated = applesEated1;
    }



    private void handleKeyPress(KeyEvent e) {
        if (!isGameRunning) {
            return;
        }

        int keyCode = e.getKeyCode();

        switch (keyCode) {
            case KeyEvent.VK_UP:
                if (direction != DOWN)
                    direction = UP;
                break;
            case KeyEvent.VK_RIGHT:
                if (direction != LEFT)
                    direction = RIGHT;
                break;
            case KeyEvent.VK_DOWN:
                if (direction != UP)
                    direction = DOWN;
                break;
            case KeyEvent.VK_LEFT:
                if (direction != RIGHT)
                    direction = LEFT;
                break;
        }
    }

    private void fireSnakeGameEvent(SnakeEvent event) {
        for (SnakeEventListener listener : eventListeners) {
            listener.onSnakeGameEvent(event);
        }
    }
}
class Coordinate {
    private int x;
    private int y;

    public Coordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Coordinate other = (Coordinate) obj;
        return x == other.x && y == other.y;
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }
}

class ScorePanel extends JPanel {

    final int width = 875;
    final int height = 100;

    private int applesEaten;

    private String name;



    public ScorePanel(){
        Border border =BorderFactory.createLineBorder(new Color(116, 66, 200), 4);
        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(width,height));
        this.setBackground(new Color(50,18,122));
        this.setFocusable(true);
        this.setBorder(border);


    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        g.drawString("Player: "+ name, 10,20);
        g.drawString("Score: " + applesEaten, 20,50);
    }

    public int getApplesEaten() {
        return applesEaten;
    }
    public void setApplesEaten(int applesEaten) {
        this.applesEaten = applesEaten;
        repaint();
    }

    public void setNickName(String nick){
        this.name = nick;
        repaint();
    }

}

class NewWindow extends JFrame {

    JLabel label = new JLabel();

    public NewWindow(){
        JFrame windowFrame = new JFrame();
        windowFrame.setBackground(Color.black);
        windowFrame.setSize(new Dimension(400,400));
        label.setText("Game Over!");
        windowFrame.setVisible(true);
    }
}
