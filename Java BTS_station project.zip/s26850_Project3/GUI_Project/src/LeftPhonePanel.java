import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;


//VSD panel (sender)
public class LeftPhonePanel extends JPanel implements ActionListener, graphSenders{


    JPanel buttonAddPanel = new JPanel();

    JButton leftAddButton = new JButton();
    JLabel leftLabel = new JLabel();

    JPanel scroll = new JPanel();
    ArrayList<GraphicalVSD> senders = new ArrayList<GraphicalVSD>();

    Updating updating;


    JOptionPane setText = new JOptionPane("Input a message" ,JOptionPane.INFORMATION_MESSAGE, JOptionPane.DEFAULT_OPTION);

    JOptionPane setNumber = new JOptionPane("Input a number", JOptionPane.INFORMATION_MESSAGE, JOptionPane.DEFAULT_OPTION);



    public LeftPhonePanel(Updating updating) {
        this.updating = updating;


        // left phone label
        Border border = BorderFactory.createLineBorder(Color.GREEN, 4);
        leftLabel.setText("Virtual sending device");
        leftLabel.setVerticalAlignment(JLabel.TOP);
        leftLabel.setHorizontalAlignment(JLabel.CENTER);
        leftLabel.setForeground(Color.WHITE);
        leftLabel.setFont(new Font("Tahoma", Font.BOLD, 12));

        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(250, 800));
        this.setBackground(Color.BLACK);
        this.setBorder(border);
        this.add(leftLabel, BorderLayout.NORTH);
        this.add(buttonAddPanel,BorderLayout.SOUTH);

        leftAddButton.setText("Add");
        leftAddButton.addActionListener(this);

        buttonAddPanel.setLayout(new BorderLayout());
        buttonAddPanel.setMaximumSize(new Dimension(250,200));
        buttonAddPanel.setBackground(Color.BLACK);
        buttonAddPanel.add(leftAddButton, BorderLayout.SOUTH);
        buttonAddPanel.setBorder(border);


        JScrollPane jScrollPane = new JScrollPane(scroll);
        scroll.setBackground(Color.BLACK);
        scroll.setLayout(new BoxLayout(scroll,  BoxLayout.Y_AXIS));

        this.add(jScrollPane,BorderLayout.CENTER);


    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String name = JOptionPane.showInputDialog("Input a message");
        String number = JOptionPane.showInputDialog("Input a number");
        GraphicalVSD graphicalVSD = new GraphicalVSD(this, updating);
        senders.add(graphicalVSD);
        scroll.add(graphicalVSD);
        VSD newVSD = new VSD(new Message(name), 1, number, updating);
        updating.addVSD(newVSD);
        newVSD.start();
        this.revalidate();
        this.repaint();

    }
    @Override
    public List<GraphicalVSD> getSenders(){
        return senders;
    }

}

interface graphSenders{
    List<GraphicalVSD> getSenders();
}



