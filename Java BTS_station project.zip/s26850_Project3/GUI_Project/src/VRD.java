import java.util.ArrayList;
import java.util.List;

public class VRD extends  Thread{

    private String receiverNumber;
    private List<Message> receivedMessages;
    private boolean cleaner;

    public boolean terminated;

    Updating updating;


    public VRD(String receiverNumber, Updating updating){
        this.receiverNumber = receiverNumber;
        this.receivedMessages = new ArrayList<>();
        this.terminated = false;
        this.cleaner = false;
        this.updating = updating;

    }

    public String getReceiverNumber(){
        return receiverNumber;
    }


    public void setCleaner(boolean clearOrNot){
        cleaner = clearOrNot;

    }

    public void receiveMessage(Message message){
        System.out.println("Message : ' " + message.toString() + " ' has been received from: "+ message.getSender() + ". The number of VRD: "+this.receiverNumber);
        receivedMessages.add(message);
        updating.getHistoryMessage().add(message.toString());
        System.out.println("Number of received messages: "+ receivedMessages.size());
    }

    // public void saveMessages(){
    //
    //}

    @Override
    public void run(){
        System.out.println("NEEEEEEGVRY");
        while (!terminated){
            try {
                Thread.sleep(1000);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
            if(cleaner){
                if(receivedMessages.size() == 10){
                    receivedMessages.clear();
                    System.out.println("MESSAGES CLEAR");
                }
            }
        }
    }

    public void setTerminated(boolean terminatedStatus){
        terminated = terminatedStatus;
    }

}
