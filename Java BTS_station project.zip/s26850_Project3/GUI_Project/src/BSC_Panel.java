import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class BSC_Panel extends JPanel {

    public static JLabel BSC_Label = new JLabel();

    public BSC_Panel() {

        //BSC label
        Border border = BorderFactory.createLineBorder(Color.GREEN, 4);

        BSC_Label.setText("BSC");
        BSC_Label.setVerticalAlignment(JLabel.TOP);
        BSC_Label.setHorizontalAlignment(JLabel.CENTER);
        BSC_Label.setForeground(Color.WHITE);
        BSC_Label.setFont(new Font("Tahoma", Font.BOLD, 12));


        this.setPreferredSize(new Dimension(100,900));
        this.setBackground(Color.DARK_GRAY);
        this.setBorder(border);
        this.add(BSC_Label);


    }

}
