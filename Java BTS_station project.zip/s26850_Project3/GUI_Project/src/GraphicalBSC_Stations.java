import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraphicalBSC_Stations extends JPanel implements ActionListener {

    JButton deleteButton = new JButton();
    JLabel graphicalBSC = new JLabel();
    Updating updating;

    graphicalBSC_Objects graphicalBSC_objects;

    public GraphicalBSC_Stations(Updating updating, graphicalBSC_Objects graphicalBSC_objects) {
        this.updating = updating;
        this.graphicalBSC_objects = graphicalBSC_objects;

        Border border = BorderFactory.createLineBorder(Color.CYAN, 2);
        System.out.println((graphicalBSC_objects.getBSC_Stations().size() + 1));
        graphicalBSC.setText("BSC tower " + (graphicalBSC_objects.getBSC_Stations().size() + 1));
        graphicalBSC.setVerticalAlignment(JLabel.TOP);
        graphicalBSC.setHorizontalAlignment(JLabel.CENTER);
        graphicalBSC.setForeground(Color.WHITE);
        graphicalBSC.setFont(new Font("Tahoma", Font.BOLD, 10));


        this.setPreferredSize(new Dimension(250, 200));
        this.setBackground(Color.DARK_GRAY);
        this.setBorder(border);

        this.setLayout(new BorderLayout());
        this.add(deleteButton, BorderLayout.SOUTH);

        deleteButton.setText("Delete BSC");
        deleteButton.addActionListener(this);
        this.add(graphicalBSC, BorderLayout.NORTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deleteButton && graphicalBSC_objects.getBSC_Stations().size() != 1) {
            Container parent = this.getParent();
            graphicalBSC_objects.getBSC_Stations().remove(parent);
            parent.remove(this);
            parent.remove(graphicalBSC);
            parent.revalidate();
            parent.repaint();

        }
    }
}
