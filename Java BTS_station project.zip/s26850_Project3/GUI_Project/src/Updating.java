import java.util.List;

public interface Updating {

    List<VRD> getVRDs();
    List<VSD> getVSDs();

    List<BTS> getBTSs();

    List<BSC> getBSCs();

    void addVRD(VRD toAdd);

    void addVSD(VSD toAdd);

    void addBTS(BTS toAdd);

    void addBSC(BSC toAdd);

    int getLayerCounter();

    List<String> getHistoryMessage();


}
