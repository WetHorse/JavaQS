import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class BTS_Panel extends JPanel implements ActionListener, graphBTS {


    ArrayList<GraphicalBTS> graphicalBTS = new ArrayList<>();
    JLabel BTS_Label = new JLabel();

    JPanel scroll = new JPanel();

    JPanel buttonPanel = new JPanel();

    JButton addButton = new JButton();


    Updating updating;
    public BTS_Panel(Updating updating) {
        this.updating = updating;
        Border border = BorderFactory.createLineBorder(Color.GREEN, 4);

        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setBorder(border);

        addButton.setText("Add BTS");
        addButton.addActionListener(this);
        addButton.setPreferredSize(new Dimension(100,50));
        buttonPanel.add(addButton, BorderLayout.SOUTH);

        this.setLayout(new BorderLayout());
        this.add(buttonPanel,BorderLayout.SOUTH);

        BTS_Label.setText("BTS");
        BTS_Label.setVerticalAlignment(JLabel.TOP);
        BTS_Label.setHorizontalAlignment(JLabel.CENTER);
        BTS_Label.setForeground(Color.WHITE);
        BTS_Label.setFont(new Font("Tahoma", Font.BOLD, 12));



        this.setPreferredSize(new Dimension(100,900));
        this.setBackground(Color.BLACK);
        this.setBorder(border);
        this.add(BTS_Label);


        JScrollPane jScrollPane = new JScrollPane(scroll);
        scroll.setBackground(Color.BLACK);
        scroll.setLayout(new BoxLayout(scroll,  BoxLayout.Y_AXIS));

        this.add(jScrollPane,BorderLayout.CENTER);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        GraphicalBTS graphBTS = new GraphicalBTS(this);
        graphicalBTS.add(graphBTS);
        scroll.add(graphBTS);
        BTS newBTS = new BTS(updating, graphicalBTS.lastIndexOf(graphBTS));
        updating.addBTS(newBTS);
        newBTS.start();
        this.revalidate();
        this.repaint();
        System.out.println("BTS elements - "+ graphicalBTS.size());
    }

    @Override
    public List<GraphicalBTS> getGraphicalBTSes() {
        return graphicalBTS;
    }
}
interface graphBTS{
    List<GraphicalBTS> getGraphicalBTSes();
}
