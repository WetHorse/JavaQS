import java.util.ArrayList;
import java.util.List;

public abstract class Station extends Thread {

    protected List<Message> messages;
    protected Updating updating;

    protected int layer;

    public Station(Updating updating, int layer) {
        this.messages = new ArrayList<>();
        this.updating = updating;
        this.layer = layer;
    }

    public void setLayer(int layer) {
        this.layer = layer;
    }

    public int getLayer() {
        return layer;
    }

    public void receiveMessage(Message message) {
        System.out.println("Message: " + message + " which was sent from: " + message.getSender().toString() + ", has been received by " + this);
        messages.add(message);
    }

    public void sendToNextLayer(Message message) {
        int min = updating.getBTSs().get(0).messages.size();
        int indexMin = 0;
        int type = 1;
        if (layer + 1 == updating.getLayerCounter()) {
            message.getReceiver().receiveMessage(message);
        } else {
            for (int i = 0; i < updating.getBTSs().size(); i++) {
                if (updating.getBTSs().get(i).layer == layer + 1) {
                    if (updating.getBTSs().get(i).messages.size() < min) {
                        min = updating.getBTSs().get(i).messages.size();
                        indexMin = i;
                        type = 1;
                    }
                }
            }

            for (int i = 0; i < updating.getBSCs().size(); i++) {
                if (updating.getBSCs().get(i).layer == layer + 1) {
                    if (updating.getBSCs().get(i).messages.size() < min) {
                        min = updating.getBSCs().get(i).messages.size();
                        indexMin = i;
                        type = 2;
                    }
                }
            }

            if (type == 1) {
                updating.getBTSs().get(indexMin).receiveMessage(message);
            } else if (type == 2) {
                updating.getBSCs().get(indexMin).receiveMessage(message);
            }
        }

    }

    public void resendMessage(){
        for(int i = 0; i< updating.getBTSs().size(); i++){
            if(updating.getBTSs().get(i).messages.size() >5){
                for(int j =0; j<updating.getBTSs().size(); j++){
                    if(updating.getBTSs().get(j).messages.size()<=5){
                        updating.getBTSs().get(j).receiveMessage(updating.getBTSs().get(i).messages.get(0));
                        updating.getBTSs().get(i).messages.remove(0);
                        System.out.println("Message has been resend from" + updating.getBTSs().get(i) + " to "+ updating.getBTSs().get(j));
                    }
                }
            }
        }
        for(int i = 0; i<updating.getBSCs().size(); i++){
            if (updating.getBSCs().get(i).messages.size() >=5){
                for (int j = 0; j<updating.getBSCs().size(); j++){
                    if(updating.getBSCs().get(j).messages.size()<5){
                        updating.getBSCs().get(j).receiveMessage(updating.getBSCs().get(i).messages.get(0));
                        updating.getBSCs().get(i).messages.remove(0);
                        System.out.println("Message has been resend from " + updating.getBSCs().get(i) + " to " + updating.getBSCs().get(j));
                    }
                }
            }
        }
    }



}












