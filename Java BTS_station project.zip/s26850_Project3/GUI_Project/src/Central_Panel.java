import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Central_Panel extends JPanel implements ActionListener, graphBSCstations {

    ArrayList<GraphicalBSC> bscStations = new ArrayList<>();
    Updating updating;


    JPanel buttonPanel = new JPanel();

    JButton plusButton = new JButton();
    JButton minusButton = new JButton();

    BTS_Panel bts_panel_left = new BTS_Panel(updating);
    BTS_Panel bts_panel_right = new BTS_Panel(updating);

    BSC_Panel bsc_panel = new BSC_Panel();
    JLabel centerLabel = new JLabel();

    JPanel scroll = new JPanel();


    public Central_Panel(Updating updating){
        this.updating = updating;
        Border border = BorderFactory.createLineBorder(Color.GREEN, 4);
        //center panel
        centerLabel.setBackground(Color.DARK_GRAY);
        this.setBackground(Color.darkGray);
        this.setPreferredSize(new Dimension(200, 200));
        this.setBorder(border);
        this.add(centerLabel);
        this.setLayout(new BorderLayout());
        this.add(bts_panel_left, BorderLayout.WEST);
        this.add(bts_panel_right, BorderLayout.EAST);
        this.add(bsc_panel, BorderLayout.CENTER);
        this.add(buttonPanel, BorderLayout.SOUTH);


        plusButton.setText("+");
        minusButton.setText("-");
        plusButton.addActionListener(this);
        minusButton.addActionListener(this);


        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setMaximumSize(new Dimension(50,50));
        buttonPanel.add(minusButton,BorderLayout.SOUTH);
        buttonPanel.add(plusButton, BorderLayout.SOUTH);

        JScrollPane jScrollPane = new JScrollPane(scroll);
        scroll.setBackground(Color.DARK_GRAY);
        scroll.setLayout(new BoxLayout(scroll,  BoxLayout.X_AXIS));

        this.add(jScrollPane,BorderLayout.CENTER);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == plusButton){
            GraphicalBSC graphicalBSC = new GraphicalBSC(updating, this);
            bscStations.add(graphicalBSC);
            scroll.add(graphicalBSC);
            this.revalidate();
            this.repaint();
        }

        if(e.getSource() == minusButton && bscStations.size() != 1){
            bscStations.remove(bscStations.size()-1);
            scroll.remove(bscStations.size()-1);
            this.revalidate();
            this.repaint();
        }
    }

    @Override
    public List<GraphicalBSC> getBscs() {
        return bscStations;
    }
}
interface graphBSCstations{
    List<GraphicalBSC> getBscs();
}