import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraphicalVRD extends JPanel implements ActionListener {


    JLabel phoneLabel = new JLabel();
    JButton deleteButton = new JButton();

    JCheckBox clearMsg = new JCheckBox();

    Updating updating;
    graphReceivers graphReceivers;

    public GraphicalVRD(Updating updating, graphReceivers graphReceivers){
        this.updating = updating;
        this.graphReceivers = graphReceivers;
        Border phoneBorder = BorderFactory.createLineBorder(Color.CYAN, 2);
        phoneLabel.setText("Phone (VRD): ");
        phoneLabel.setVerticalAlignment(JLabel.TOP);
        phoneLabel.setHorizontalAlignment(JLabel.CENTER);
        phoneLabel.setForeground(Color.WHITE);
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 10));



        this.setMaximumSize(new Dimension(250, 150));
        this.add(phoneLabel, BorderLayout.NORTH);

        this.setBackground(Color.BLACK);
        this.setBorder(phoneBorder);


        this.setLayout(new BoxLayout(this,  BoxLayout.Y_AXIS));
        this.add(clearMsg);
        this.add(deleteButton, BorderLayout.AFTER_LAST_LINE);



        clearMsg.addActionListener(this);
        clearMsg.setText("Clear messages? ");
        clearMsg.setPreferredSize(new Dimension(250,20));



        deleteButton.addActionListener(this);
        deleteButton.setText("Delete VRD");
        deleteButton.setBounds(new Rectangle(50,50));


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == deleteButton){
            Container parent = this.getParent();
            updating.getVRDs().get(updating.getVRDs().size()-1).setTerminated(true);
            parent.remove(graphReceivers.getRecievers().get(graphReceivers.getRecievers().size()-1));
            parent.remove(this);
            parent.remove(phoneLabel);
            parent.revalidate();
            parent.repaint();
        }
        if(e.getSource() == clearMsg){
            updating.getVRDs().get(updating.getVRDs().size()-1).setCleaner(true);
        }

    }
}
