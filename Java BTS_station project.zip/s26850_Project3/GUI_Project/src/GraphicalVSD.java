import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraphicalVSD extends JPanel implements ActionListener, ChangeListener {


    JLabel phoneLabel = new JLabel();
    JButton deleteButton = new JButton();

    graphSenders graphSenders;
    Updating updating;
    JSlider slider = new JSlider(1,10,5);

    String activeDisabled [] = {"Active", "Disabled"};
    JComboBox comboBox = new JComboBox<>(activeDisabled);

    public GraphicalVSD(graphSenders graphSenders, Updating updating){
        this.graphSenders = graphSenders;
        this.updating = updating;

        Border phoneBorder = BorderFactory.createLineBorder(Color.CYAN, 2);
        phoneLabel.setText("Phone (VSD): ");
        phoneLabel.setVerticalAlignment(JLabel.TOP);
        phoneLabel.setHorizontalAlignment(JLabel.CENTER);
        phoneLabel.setForeground(Color.WHITE);
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 10));


        this.setMaximumSize(new Dimension(250, 200));


        this.setBackground(Color.BLACK);
        this.setBorder(phoneBorder);

        this.setLayout(new BorderLayout());
        this.add(phoneLabel, BorderLayout.NORTH);

        deleteButton.addActionListener(this);
        deleteButton.setText("Delete VSD");
        deleteButton.setBounds(new Rectangle(50,50));



        comboBox.addActionListener(this);



        slider.setPreferredSize(new Dimension(250,70));
        slider.setPaintTicks(true);
        slider.setMinorTickSpacing(3);
        slider.setPaintLabels(true);
        slider.addChangeListener(this);

        this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        this.add(comboBox);
        this.add(slider);
        this.add(deleteButton);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == deleteButton){
            Container parent = this.getParent();
            updating.getVSDs().get(updating.getVSDs().size()-1).setTerminated(true);
            parent.remove(graphSenders.getSenders().get(graphSenders.getSenders().size()-1));
            parent.remove(this);
            parent.remove(phoneLabel);
            parent.revalidate();
            parent.repaint();
        }
        if(e.getSource() == comboBox){
            if(comboBox.getSelectedItem() == "Active"){
                updating.getVSDs().get(updating.getVSDs().size()-1).setTerminated(false);
            }else if(comboBox.getSelectedItem() == "Disabled"){
                updating.getVSDs().get(updating.getVSDs().size()-1).setTerminated(true);
            }
        }

    }

    @Override
    public void stateChanged(ChangeEvent e) {
        updating.getVSDs().get(updating.getVSDs().size()-1).setFrequency(slider.getValue());
    }
}
