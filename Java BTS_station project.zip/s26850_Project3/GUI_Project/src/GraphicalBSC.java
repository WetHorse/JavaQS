import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class GraphicalBSC extends JPanel implements ActionListener,graphicalBSC_Objects {

    ArrayList<GraphicalBSC_Stations> graphicalBSC_stations = new ArrayList<>();
    JButton addButton = new JButton();
    JLabel bscLabel = new JLabel();

    JPanel scroll = new JPanel();
    Updating updating;
    graphBSCstations graphBSCstations;



    public GraphicalBSC(Updating updating, graphBSCstations graphBSCstations){
        this.updating = updating;
        this.graphBSCstations = graphBSCstations;


        Border border = BorderFactory.createLineBorder(Color.CYAN, 2);
        bscLabel.setText("BSC tower " );
        bscLabel.setVerticalAlignment(JLabel.TOP);
        bscLabel.setHorizontalAlignment(JLabel.CENTER);
        bscLabel.setForeground(Color.WHITE);
        bscLabel.setFont(new Font("Tahoma", Font.BOLD, 10));


        this.setPreferredSize(new Dimension(100,600));

        this.setBackground(Color.DARK_GRAY);
        this.setBorder(border);

        this.setLayout(new BorderLayout());
        this.add(bscLabel,BorderLayout.NORTH);
        this.add(addButton, BorderLayout.SOUTH);

        addButton.setText("Add BSC");
        addButton.addActionListener(this);
        addButton.setBounds(new Rectangle(100,50));


        JScrollPane jScrollPane = new JScrollPane(scroll);
        scroll.setBackground(Color.DARK_GRAY);
        scroll.setLayout(new BoxLayout(scroll,  BoxLayout.Y_AXIS));

        this.add(jScrollPane,BorderLayout.CENTER);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == addButton){
            GraphicalBSC_Stations graphicalBSCs = new GraphicalBSC_Stations(updating,this);
            graphicalBSC_stations.add(graphicalBSCs);
            scroll.add(graphicalBSCs);
            this.revalidate();
            this.repaint();
        }
    }

    @Override
    public List<GraphicalBSC_Stations> getBSC_Stations() {
        return graphicalBSC_stations;
    }
}
interface graphicalBSC_Objects{
    List<GraphicalBSC_Stations> getBSC_Stations();
}