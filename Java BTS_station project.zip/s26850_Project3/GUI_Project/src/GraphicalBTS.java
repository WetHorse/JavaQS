import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraphicalBTS extends JPanel implements ActionListener {

//    BTS_Panel bts_panel = new BTS_Panel();
    private graphBTS graphBTS;

    JLabel btsLabel = new JLabel();
    JButton btsDeleteButton = new JButton();


    public GraphicalBTS(graphBTS graphBTS){
        this.graphBTS = graphBTS;
        Border border = BorderFactory.createLineBorder(Color.CYAN, 2);
        System.out.println((graphBTS.getGraphicalBTSes().size()+1));
        btsLabel.setText("BTS tower "+ (graphBTS.getGraphicalBTSes().size()+1));
        btsLabel.setVerticalAlignment(JLabel.TOP);
        btsLabel.setHorizontalAlignment(JLabel.CENTER);
        btsLabel.setForeground(Color.WHITE);
        btsLabel.setFont(new Font("Tahoma", Font.BOLD, 10));


        this.setMaximumSize(new Dimension(100,200));


        this.setBackground(Color.BLACK);
        this.setBorder(border);

        this.setLayout(new BorderLayout());
        this.add(btsDeleteButton, BorderLayout.SOUTH);

        btsDeleteButton.setText("Delete BTS");
        btsDeleteButton.addActionListener(this);
        this.add(btsLabel, BorderLayout.NORTH);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btsDeleteButton && graphBTS.getGraphicalBTSes().size() != 1){
            Container parent = this.getParent();
            graphBTS.getGraphicalBTSes().remove(parent);
            parent.remove(this);
            parent.remove(btsLabel);
            parent.revalidate();
            parent.repaint();

        }
    }
}
