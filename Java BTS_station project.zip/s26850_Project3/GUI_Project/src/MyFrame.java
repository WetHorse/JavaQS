import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;

public class MyFrame extends JFrame {
    private Updating updating;


    MyFrame(Updating updating){
        this.updating = updating;
        JFrame frame = new JFrame();

        // ---Graphics---

        frame.setVisible(true);
        frame.setSize(1600, 900);
        frame.setTitle("Mobile application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        frame.setLayout(new BorderLayout());


        RightPhonePanel rightPhonePanel = new RightPhonePanel(updating);
        LeftPhonePanel leftPhonePanel = new LeftPhonePanel(updating);
        Central_Panel centerPanel = new Central_Panel(updating);

        frame.add(rightPhonePanel, BorderLayout.EAST);
        frame.add(leftPhonePanel, BorderLayout.WEST);
        frame.add(centerPanel, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                String fileName = "historyOfMesssages.bin";
                try (OutputStream outputStream = new FileOutputStream(fileName);
                     ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream)) {

                    objectOutputStream.writeObject(updating.getHistoryMessage());
                    System.out.println("History of messages has been written to the binary file.");

                } catch (IOException ex) {
                    System.out.println("An error occurred while writing to the file: " + ex.getMessage());
                }

            }
        });

    }


}