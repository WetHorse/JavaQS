import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class RightPhonePanel extends JPanel implements ActionListener, graphReceivers {

    ArrayList<GraphicalVRD> receivers = new ArrayList<>();
    JPanel buttonAddPanel = new JPanel();
    JPanel scroll = new JPanel();
    JButton rightAddButton = new JButton();
    JLabel rightLabel = new JLabel();

    Updating updating;
    public RightPhonePanel(Updating updating) {
        this.updating = updating;

        Border border = BorderFactory.createLineBorder(Color.GREEN, 4);
        rightLabel.setText("Virtual receiving device");
        rightLabel.setVerticalAlignment(JLabel.TOP);
        rightLabel.setHorizontalAlignment(JLabel.CENTER);
        rightLabel.setForeground(Color.WHITE);
        rightLabel.setFont(new Font("Tahoma", Font.BOLD, 12));

        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(250, 800));
        this.setBackground(Color.BLACK);
        this.setBorder(border);
        this.add(rightLabel, BorderLayout.NORTH);
        this.add(buttonAddPanel, BorderLayout.SOUTH);

        rightAddButton.setText("Add");
        rightAddButton.addActionListener(this);

        buttonAddPanel.setLayout(new BorderLayout());
        buttonAddPanel.setMaximumSize(new Dimension(250,50));
        buttonAddPanel.setBackground(Color.BLACK);
        buttonAddPanel.add(rightAddButton, BorderLayout.SOUTH);
        buttonAddPanel.setBorder(border);


        JScrollPane jScrollPane = new JScrollPane(scroll);
        scroll.setBackground(Color.BLACK);
        scroll.setLayout(new BoxLayout(scroll,  BoxLayout.Y_AXIS));

        this.add(jScrollPane,BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        GraphicalVRD graphicalVRD = new GraphicalVRD(updating,this);
        receivers.add(graphicalVRD);
        scroll.add(graphicalVRD);
        this.revalidate();
        this.repaint();
    }

    @Override
    public List<GraphicalVRD> getRecievers() {
        return receivers;
    }
}

interface graphReceivers{
    List<GraphicalVRD> getRecievers();
}