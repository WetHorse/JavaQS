public class Message {
    private VSD sender;
    private VRD receiver;
    private final String content;

    public Message(String content){
        this.content = content;
    }

    public void setSender(VSD sender){
        this.sender = sender;
    }

    public void setReceiver(VRD receiver){
        this.receiver = receiver;
    }

    public VSD getSender(){
        return sender;
    }

    public VRD getReceiver(){
        return receiver;
    }

    @Override
    public String toString() {
        return content;
    }
}
