public class VSD extends Thread{
    private Message message;
    private String senderNumber;
    private int frequency;

    Updating updating;

    private boolean active;
    private boolean terminated;

    public VSD(Message message, int frequency, String senderNumber, Updating updating){
        this.message = message;
        this.senderNumber = senderNumber;
        this.updating = updating;
        this.frequency = frequency;

        this.active = true;
        this.terminated = false;
        this.message.setSender(this);
    }

    public void setMessage(Message message){
        this.message = message;
    }

    public void setFrequency(int setFrequency){
        frequency = setFrequency;
    }


    @Override
    public void run(){
        while (!terminated){
            try{
                Thread.sleep(1000/frequency);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
            sendMessage();
        }
    }

    public void sendMessage(){

        if (updating.getVRDs().size() != 0) {
            int index = (int) (Math.random() * updating.getVRDs().size());
            message.setReceiver(updating.getVRDs().get(index));
            for (int i = 0; i < updating.getBTSs().size(); i++) {
                if (updating.getBTSs().get(i).layer == 0) {
                    updating.getBTSs().get(i).receiveMessage(message);
                }
            }
        }

    }

    public void setTerminated(boolean terminatedStatus){
        terminated = terminatedStatus;
    }
}

