import java.util.ArrayList;
import java.util.List;

public class Application implements Updating{
    private final List<VRD> vrdList;
    private final List<VSD> vsdList;

    private final List<BTS>  btsList;

    private final List<BSC> bscList;

    public int layerCounter =3;

    private final List<String> historyOfMessages;


    public Application(){
        this.vrdList = new ArrayList<>();
        this.vsdList = new ArrayList<>();
        this.btsList= new ArrayList<>();
        this.bscList = new ArrayList<>();
        this.historyOfMessages = new ArrayList<>();


        BTS bts1 = new BTS(this, 0);
        BSC bsc = new BSC(this,1);
        BTS bts2 = new BTS(this,2);

        bts1.start();
        bsc.start();
        bts2.start();


        btsList.add(bts1);
        bscList.add(bsc);
        btsList.add(bts2);

        VRD rec1 = new VRD("2345678905678", this);
        vrdList.add(rec1);
        vrdList.add(rec1);
        rec1.start();

//        Message message = new Message("Hello");
//        VSD sms = new VSD(message,3, "8-800-555-35-35",this);
//        sms.setMessage(message);
//        sms.start();


    }

    @Override
    public List<VRD> getVRDs() {
        return vrdList;
    }

    @Override
    public List<VSD> getVSDs() {
        return vsdList;
    }

    @Override
    public List<BTS> getBTSs() {
        return btsList;
    }

    @Override
    public List<BSC> getBSCs() {
        return bscList;
    }

    @Override
    public void addVRD(VRD toAdd) {
        vrdList.add(toAdd);
    }

    @Override
    public void addVSD(VSD toAdd) {
        vsdList.add(toAdd);
    }

    @Override
    public void addBTS(BTS toAdd) {
        btsList.add(toAdd);
    }

    @Override
    public void addBSC(BSC toAdd) {
        bscList.add(toAdd);
    }

    @Override
    public int getLayerCounter() {
        return layerCounter;
    }

    @Override
    public List<String> getHistoryMessage() {
        return historyOfMessages;
    }

}


class BTS extends Station{

    int typeOfStation =1; //Bts station number
    int counter = 0;
    List<Message> messages;

    public BTS(Updating updating, int layer) {
        super(updating, layer);
        this.messages = super.messages;
    }


    @Override
    public void run(){
        while (isAlive()) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (messages.size() > 0) {
                counter++;
                if (counter == 3) {
                    sendToNextLayer(messages.get(0));
                    messages.remove(0);
                    counter = 0;
                    resendMessage();
                }
            }
        }
    }


    @Override
    public void receiveMessage(Message message) {
        super.receiveMessage(message);
    }
    @Override
    public void sendToNextLayer(Message message) {
        super.sendToNextLayer(message);
    }

    @Override
    public String toString() {
        return "BTS{" +
                "typeOfStation=" + typeOfStation +
                '}';
    }
}






class BSC extends Station{

    int typeOfStation = 2; //Bsc station number

    public BSC(Updating updating, int layer) {
        super(updating, layer);
    }



    @Override
    public void run(){
        while (isAlive()) {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (messages.size() > 0) {
                sendToNextLayer(messages.get(0));
                messages.remove(0);
                resendMessage();
            }
        }
    }

    @Override
    public void receiveMessage(Message message) {
        super.receiveMessage(message);
    }

    @Override
    public void sendToNextLayer(Message message) {
        super.sendToNextLayer(message);
    }

    @Override
    public String toString() {
        return "BSC{" +
                "typeOfStation=" + typeOfStation +
                '}';
    }


}


