package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

class CountryTable {

    public String countriesFileName;
    public Map<String, ImageIcon> flagImages;

    public CountryTable(String countriesFileName) {
        this.countriesFileName = countriesFileName;
        flagImages = new HashMap<>();
        loadFlagImagesFromFolder("data/flags");
    }

    public void loadFlagImagesFromFolder(String folderPath) {
        File folder = new File(folderPath);
        if (folder.isDirectory()) {
            for (File file : folder.listFiles()) {
                if (file.isFile() && file.getName().endsWith(".png")) {
                    String countryName = file.getName().replace(".png", "");
                    flagImages.put(countryName, new ImageIcon(file.getAbsolutePath()));
                }
            }
        }
    }

    public JTable create() {
        DefaultTableModel tableModel = new DefaultTableModel() {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 2) {
                    return Integer.class;
                }else if(columnIndex == 3){
                    return ImageIcon.class;
                }
                return super.getColumnClass(columnIndex);
            }
        };

        try (BufferedReader reader = new BufferedReader(new FileReader(countriesFileName))) {
            String headerLine = reader.readLine();
            String[] headers = headerLine.split("\t");
            tableModel.setColumnIdentifiers(headers);


            String line;
            while ((line = reader.readLine()) != null) {
                String[] rowData = line.split("\t");
                tableModel.addRow(rowData);

                String countryName = rowData[0];
                ImageIcon flagImage = flagImages.get(countryName);
                if (flagImage != null) {
                    tableModel.setValueAt(flagImage, tableModel.getRowCount() - 1, 3); // add
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JTable table = new JTable(tableModel) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component component = super.prepareRenderer(renderer, row, column);

                if (column == 2 && component instanceof JLabel) {
                    JLabel label = (JLabel) component;
                    int population = Integer.parseInt(getValueAt(row, column).toString());

                    if (population > 20000000) {
                        label.setForeground(Color.RED);
                        label.setFont(label.getFont().deriveFont(Font.BOLD));
                    } else {
                        label.setForeground(Color.BLACK);
                        label.setFont(label.getFont().deriveFont(Font.PLAIN));
                    }
                }

                return component;
            }
        };

        return table;
    }

}