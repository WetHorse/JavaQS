

import com.sun.tools.javac.Main;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.ArrayList;

/*
Dirichlet's theorem (6k+1)
  All numbers - 6 spirals
  Simple numbers - only two spirals
 Simple numbers cannot be multiplied by 6, we cannot add 2, 4 ,3
 only 3 is simple number (exception).
 All simple numbers, exception 2,3 bigger than values which can
 by 6 on 1 or 5.
 */



public class s26850 extends Frame {

    public static ArrayList<Integer> primes = new ArrayList<>();

    //sieve of Eratosthenes
    public static void soE(int maxVal, ArrayList<Integer> primes) {
        boolean[] isPrime = new boolean[maxVal];
        Arrays.fill(isPrime, true);

        for (int i = 2; i*i < maxVal; i++) {
            if (isPrime[i]) {
                for (int j = 2 * i; j < maxVal; j += i) {
                    isPrime[j] = false;
                }
            }
        }
        for (int i = 2; i < maxVal; i++) {
            if (isPrime[i]) {
                primes.add(i);
            }
        }
    }


    public void pintLines(Graphics g) {
        g.setColor(Color.CYAN);

        int max_step = 3;
        int step = 0;

        int x = this.getSize().width / 2 - 1;
        int y = this.getSize().height / 2 - 1; //Start coordinates

        int stage = 1; //Rotation stage
        int val = 3; // start prime number
        int k = 1; //start index of array
        if (k <= primes.size()) {
            while (stage <= 5399) {
                while (val <= 10800 * 10800) {
                    while (k <= primes.size()) {
                        if (stage % 2 != 0) {
                            while (step < max_step) {
                                if (val == primes.get(k)) {
                                    g.fillRect(x, y, 1, 1);
                                    k++;
                                }
                                step++;
                                y = y + 1;
                                val++;
                            }
                            step = 0;
                            while (step < max_step) {
                                if (val == primes.get(k)) {
                                    g.fillRect(x, y, 1, 1);
                                    k++;
                                }
                                step++;
                                x = x - 1;
                                val++;
                            }
                            step = 0;
                            max_step = max_step + 1;
                            stage++;
                        } else {
                            while (step < max_step) {
                                if (val == primes.get(k)) {
                                    g.fillRect(x, y, 1, 1);
                                    k++;
                                }
                                step++;
                                y = y - 1;
                                val++;
                            }
                            step = 0;
                            while (step < max_step) {
                                if (val == primes.get(k)) {
                                    g.fillRect(x, y, 1, 1);
                                    k++;
                                }
                                step++;
                                x = x + 1;
                                val++;
                            }
                            step = 0;
                            max_step = max_step + 1;
                            stage++;

                        }
                    }
                }
            }
        }
    }


    public static void main(String[] args) throws IOException {
        soE(10800* 10800, primes);

        FileOutputStream outputStream;
        try {
            outputStream = new FileOutputStream("binary_file.bin");

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        DataOutputStream dataOutStream = new DataOutputStream(outputStream);


        byte[] numberBytes = new byte[8];




//        double one_byte = ((Math.log10(Math.pow(2, 8) - 1)) / Math.log10(2));
//        double two_bytes = ((Math.log10(Math.pow(2, 16) - 1)) / Math.log10(2));
//        double three_bytes = ((Math.log10(Math.pow(2, 24) - 1)) / Math.log10(2));
//        double four_bites = ((Math.log10(Math.pow(10800, 2))) / Math.log10(2));


        //Probably it will make our performance higher, if we will not take a logarithm

        double one_byte = Math.pow(2,8)-1;
        double two_bytes = Math.pow(2,16)-1;
        double three_bytes = Math.pow(2,24)-1;
        double four_bytes = Math.pow(10800,2); //less than 4 bytes


//        test.record(s26850.primes, 0, one_byte, 0, numberBytes, outputStream);
//        System.out.println(test.indexes.get(0));
//        test.record(s26850.primes, test.indexes.get(0), two_bytes, 0, numberBytes, outputStream);
//        System.out.println(test.indexes.get(1));
//        test.record(s26850.primes, test.indexes.get(1), three_bytes, 0, numberBytes, outputStream);
//        System.out.println(test.indexes.get(2));
//        test.record(s26850.primes, test.indexes.get(2), four_bytes, 0, numberBytes, outputStream);

        dataOutStream.close();
        outputStream.close();

        new s26850();
    }

    public s26850() {
//        this.setLocationRelativeTo(null);
        this.setSize(1080, 1080);
        this.setTitle("The Ulam spiral");
        this.setVisible(true);
        this.setBackground(Color.BLACK);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        pintLines(g);
    }

}


class test {

    public static ArrayList<Integer> indexes = new ArrayList<>();

    public static void record(ArrayList<Integer> primes, int lastIndex, double volume, long count, byte[] numberBytes, FileOutputStream outputStream) throws IOException {
        int until = 0;
        int index = 0;
        for (int i = lastIndex; i < primes.size(); i++) {

            if (/*Math.log10(primes.get(i)) / (Math.log10(2))*/primes.get(i) <= volume) {
                until = primes.get(i);
                count++;
                index = primes.indexOf(until);
            } else {
                break;
            }
        }
        indexes.add(index+1);
        for (int i = 0; i < numberBytes.length; i++) {
            numberBytes[i] = (byte) ((count >> (i * 8)) & 0xff);
        }

        outputStream.write(numberBytes);
        for (int i = 0; i < primes.indexOf(until); i++) {
            outputStream.write(primes.get(i));
        }
    }
}


